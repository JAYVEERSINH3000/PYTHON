from rest_framework import serializers
from .models import Movie

class MovieSerializers(serializers.ModelSerializer):
   class Meta:
      model = Movie
      fields = ['id','title','director','release_year']  # or field = '__all__'