from django.urls import path
from accounts import views

urlpatterns = [
    path('signupaccount/',views.signupaccount,name="signupaccount"),
]
