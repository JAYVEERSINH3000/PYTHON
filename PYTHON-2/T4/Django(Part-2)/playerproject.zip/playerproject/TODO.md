# TODO - playerproject/playerapp (Django Player CRUD)

- [ ] Update `playerapp/models.py` to match required fields: `name`, `test_innings`, `runs`
- [ ] Register `Player` in `playerapp/admin.py`
- [ ] Implement views in `playerapp/views.py`: `home` (list+search), `add_player`, `edit_player`, `delete_player`, `welcome`
- [ ] Update URL routing in `playerproject/urls.py` and `playerapp/urls.py` for add/edit/delete
- [ ] Update templates:
  - [ ] `templates/home.html` to show navbar, search, player table w/ Edit/Delete links, and add_player link / no-results text
  - [ ] `templates/add.html` to be the add_player form (GET/POST)
  - [ ] Create `templates/edit.html` for editing form (pre-filled)
- [ ] Run migrations: `makemigrations` + `migrate`
- [ ] Run server and manually verify UI matches spec.

