from django.urls import path
from movie import views as movieViews

urlpatterns = [
    path('<int:movie_id>',movieViews.detail,name="detail")
]
