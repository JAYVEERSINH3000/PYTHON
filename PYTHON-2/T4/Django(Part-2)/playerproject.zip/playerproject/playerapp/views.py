from django.shortcuts import redirect, render, get_object_or_404

from .models import Player


def home(request):
    q = (request.GET.get("q") or "").strip()
    players = Player.objects.all().order_by("name")

    if q:
        players = players.filter(name__icontains=q)

    context = {"players": players, "q": q}
    return render(request, "home.html", context)



def welcome(request):
    return render(request, "welcome.html")


def add_player(request):
    if request.method == "POST":
        name = (request.POST.get("name") or "").strip()
        test_innings = request.POST.get("test_innings")
        runs = request.POST.get("runs")

        Player.objects.create(
            name=name,
            test_innings=int(test_innings),
            runs=int(runs),
        )
        return redirect("home")

    return render(request, "add.html")


def edit_player(request, player_id):
    player = get_object_or_404(Player, id=player_id)

    if request.method == "POST":
        player.name = (request.POST.get("name") or "").strip()
        player.test_innings = int(request.POST.get("test_innings"))
        player.runs = int(request.POST.get("runs"))
        player.save()
        return redirect("home")

    return render(
        request,
        "edit.html",
        {
            "player": player,
        },
    )


def delete_player(request, player_id):
    player = get_object_or_404(Player, id=player_id)
    if request.method in ("POST", "GET"):
        player.delete()
    return redirect("home")

