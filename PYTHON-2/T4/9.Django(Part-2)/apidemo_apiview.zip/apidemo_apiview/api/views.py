from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Movie
from .serializers import MovieSerializers
# Create your views here.


@api_view(['GET','POST'])
def movie_list(request):
   if request.method == 'GET':
      movie_d = Movie.objects.all()
      serializer = MovieSerializers(movie_d,many=True)
      return Response(serializer.data)
   elif request.method == 'POST':
      serializer = MovieSerializers(data=request.data)
      if serializer.is_valid():
         serializer.save()
         return Response(serializer.data,status=status.HTTP_201_CREATED)
      return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET','PUT','DELETE'])
def movie_detail(request,pk):
   try:
      movie= Movie.objects.get(pk=pk)
   except movie.DoesNotExist:
      return Response(status=status.HTTP_404_NOT_FOUND)
   if request.method == 'GET':
      serializer = MovieSerializers(movie)
      return Response(serializer.data)
   elif request.method == 'PUT':
        serializer=MovieSerializers(movie,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
   
   if request.method =="DELETE":
        movie.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
