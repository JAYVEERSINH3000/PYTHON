from django.urls import path
from api import views

urlpatterns = [
   path('movies/',views.movie_list,name='movie_list'),
   path('movies/<int:pk>/',views.movie_detail,name='movie-detail'),
]