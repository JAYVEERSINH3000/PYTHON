from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Player(models.Model):
    name = models.CharField(max_length=100)
    test_innings = models.IntegerField()
    runs = models.IntegerField()

    def __str__(self):
        return self.name

    