from django.contrib import admin
from django.urls import path
from studentapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Core application Routes
    path("", views.home_view, name="home"),
    path("welcome/", views.welcome_view, name="welcome"),
    path("add/", views.add_student_view, name="add_student"),
    path("edit/<int:pk>/", views.edit_student_view, name="edit_student"),
    path("delete/<int:pk>/", views.delete_student_view, name="delete_student"),
]